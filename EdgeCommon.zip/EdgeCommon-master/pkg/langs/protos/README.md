After changing the messages, remember to run 'langs generate' to generate Go codes:
~~~bash
go run cmd/langs/main.go generate
~~~