# 域名信息

## 示例
~~~json
{
  "name": "example.com",
  "type": "full"
}
~~~