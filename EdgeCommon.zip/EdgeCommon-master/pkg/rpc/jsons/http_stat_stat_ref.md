# 统计引用
## 定义
~~~json
{
  "isPrior": "是否覆盖父级配置",
  "isOn": "是否启用配置"
}
~~~

## 示例
~~~json
{
  "isPrior": true,
  "isOn": true
}
~~~