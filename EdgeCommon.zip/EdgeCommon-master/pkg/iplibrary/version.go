// Copyright 2022 GoEdge CDN goedge.cdn@gmail.com. All rights reserved. Official site: https://goedge.cn .

package iplibrary

type Version = int

const (
	Version1 Version = 1
	Version2 Version = 2 // 主要变更为数字使用32进制
)
