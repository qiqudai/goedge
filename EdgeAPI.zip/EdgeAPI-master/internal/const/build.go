// Copyright 2021 GoEdge CDN goedge.cdn@gmail.com. All rights reserved.
//go:build !plus
// +build !plus

package teaconst

const BuildCommunity = true
const BuildPlus = false
const Tag = "community"
