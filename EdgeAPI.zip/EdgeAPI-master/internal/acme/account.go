// Copyright 2021 GoEdge CDN goedge.cdn@gmail.com. All rights reserved.

package acme

type Account struct {
	EABKid string
	EABKey string
}
