package models

import (
	_ "github.com/go-sql-driver/mysql"
)
