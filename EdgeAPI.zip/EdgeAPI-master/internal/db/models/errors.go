package models

import "github.com/TeaOSLab/EdgeAPI/internal/errors"

var ErrNotFound = errors.New("resource not found")
