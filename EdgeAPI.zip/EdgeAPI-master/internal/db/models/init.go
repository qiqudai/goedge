package models

import (
	_ "github.com/iwind/TeaGo/bootstrap"
)
