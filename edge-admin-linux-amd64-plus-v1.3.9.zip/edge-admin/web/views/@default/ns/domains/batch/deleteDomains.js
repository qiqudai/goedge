Tea.context(function () {
	this.success = NotifyReloadSuccess("删除成功")
})