Tea.context(function () {
	this.success = NotifySuccess("保存成功", "/ns/clusters/cluster?clusterId=" + this.clusterId);
});