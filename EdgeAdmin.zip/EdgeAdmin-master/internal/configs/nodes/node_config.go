package nodes

type NodeConfig struct {
	Id string `json:"id" yaml:"id"`
	Secret string `json:"secret" yaml:"secret"`
}
