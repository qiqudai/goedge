package configs

var Secret = ""
