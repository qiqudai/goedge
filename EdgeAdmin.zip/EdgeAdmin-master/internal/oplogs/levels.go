package oplogs

const (
	LevelNone  = "none"
	LevelInfo  = "info"
	LevelDebug = "debug"
	LevelWarn  = "warn"
	LevelError = "error"
	LevelFatal = "fatal"
)
