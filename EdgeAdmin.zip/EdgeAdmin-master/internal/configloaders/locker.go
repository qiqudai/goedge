package configloaders

import "sync"

var locker sync.Mutex
