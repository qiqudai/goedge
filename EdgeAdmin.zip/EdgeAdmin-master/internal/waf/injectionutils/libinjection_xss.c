#define LIBINJECTION_VERSION "3.9.1"

#include "libinjection/src/libinjection_xss.c"
#include "libinjection/src/libinjection_html5.c"

#define GOEDGE_VERSION "25" // last version is for GoEdge change