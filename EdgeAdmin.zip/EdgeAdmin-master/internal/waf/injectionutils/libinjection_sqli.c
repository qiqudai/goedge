#define LIBINJECTION_VERSION "3.9.1"

#include "libinjection/src/libinjection_sqli.c"