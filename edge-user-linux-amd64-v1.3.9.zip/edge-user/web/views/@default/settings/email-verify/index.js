Tea.context(function () {
	this.success = function () {
		teaweb.successRefresh("已将激活邮件发送到你的邮箱中，请注意查收")
	}
})