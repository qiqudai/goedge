Tea.context(function () {
	this.goIndividual = function () {
		window.location = "/settings/identity/individual"
	}

	this.goEnterprise = function () {
		window.location = "/settings/identity/enterprise"
	}
})