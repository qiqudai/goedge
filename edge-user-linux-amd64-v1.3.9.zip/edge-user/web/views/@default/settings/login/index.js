Tea.context(function () {
	this.password = ""
	this.success = NotifyReloadSuccess("保存成功")
})