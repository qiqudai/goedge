Tea.context(function () {
	this.deleteUserPlan = function (userPlanId) {
		teaweb.confirm("确定要删除此套餐吗？", function () {
			this.$post(".delete")
				.params({
					userPlanId: userPlanId
				})
				.refresh()
		})
	}

	this.renewUserPlan = function (userPlanId) {
		teaweb.popupSuccess(".renewPopup?userPlanId=" + userPlanId, null, "27em")
	}
})