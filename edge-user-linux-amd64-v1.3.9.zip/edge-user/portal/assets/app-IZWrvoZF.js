import{c as e,o as a,L as t,S as c}from"./app-xg-RHuhr.js";const o={__name:"index",setup(p){return(r,s)=>(a(),e(t,{"active-top-menu":"products"}))}};c({app:o});
