package caches

type Stat struct {
	Count     int   // 数量
	ValueSize int64 // 值占用的空间
	Size      int64 // 占用的空间尺寸
}
