// Copyright 2021 GoEdge goedge.cdn@gmail.com. All rights reserved.

package caches

type HotItem struct {
	Key  string
	Hits uint32
}
