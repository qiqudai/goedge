// Copyright 2023 GoEdge goedge.cdn@gmail.com. All rights reserved. Official site: https://goedge.cn .
//go:build linux && !plus

package nftables

func (this *Set) initElements() {
	// NOT IMPLEMENTED
}
