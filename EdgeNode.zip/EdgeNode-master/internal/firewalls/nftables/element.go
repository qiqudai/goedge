// Copyright 2022 GoEdge goedge.cdn@gmail.com. All rights reserved.
//go:build linux
// +build linux

package nftables

type Element struct {
}
