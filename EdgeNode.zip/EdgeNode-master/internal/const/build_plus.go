// Copyright 2021 GoEdge goedge.cdn@gmail.com. All rights reserved.
//go:build plus
// +build plus

package teaconst

const BuildCommunity = false
const BuildPlus = true
const Tag = "plus"
