// Copyright 2021 GoEdge goedge.cdn@gmail.com. All rights reserved.

package monitor

// ItemValue 数据值定义
type ItemValue struct {
	Item      string
	ValueJSON []byte
	CreatedAt int64
}
