// Copyright 2021 GoEdge goedge.cdn@gmail.com. All rights reserved.
//go:build !script
// +build !script

package nodes

func (this *HTTPRequest) onInit() {
}

func (this *HTTPRequest) onRequest() {
}
