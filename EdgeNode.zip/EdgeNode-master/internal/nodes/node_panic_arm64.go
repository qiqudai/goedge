// Copyright 2021 GoEdge goedge.cdn@gmail.com. All rights reserved.
//go:build arm64

package nodes

// 处理异常
func (this *Node) handlePanic() {

}
