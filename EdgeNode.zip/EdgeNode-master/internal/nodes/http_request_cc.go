// Copyright 2023 GoEdge goedge.cdn@gmail.com. All rights reserved. Official site: https://goedge.cn .
//go:build !plus

package nodes

func (this *HTTPRequest) doCC() (block bool) {
	return
}
