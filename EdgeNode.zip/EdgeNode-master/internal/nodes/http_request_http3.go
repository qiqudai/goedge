// Copyright 2023 GoEdge CDN goedge.cdn@gmail.com. All rights reserved. Official site: https://goedge.cn .
//go:build !plus

package nodes

import "net/http"

func (this *HTTPRequest) processHTTP3Headers(respHeader http.Header) {
	// stub
}
