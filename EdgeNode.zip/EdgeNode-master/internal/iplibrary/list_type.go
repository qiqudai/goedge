package iplibrary

type IPListType = string

const (
	IPListTypeWhite IPListType = "white"
	IPListTypeBlack IPListType = "black"
)
