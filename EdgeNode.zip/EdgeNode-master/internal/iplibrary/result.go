package iplibrary

type Result struct {
	CityId   int64
	Country  string
	Region   string
	Province string
	City     string
	ISP      string
}
