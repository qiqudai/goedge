// +build linux
// 可以在 /usr/include/asm-generic/socket.h 中找到 SO_REUSEPORT 值

package utils

const SO_REUSEPORT = 15
