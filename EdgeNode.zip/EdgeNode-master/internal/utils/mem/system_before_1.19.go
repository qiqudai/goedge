// Copyright 2023 GoEdge goedge.cdn@gmail.com. All rights reserved. Official site: https://goedge.cn .
//go:build !go1.19

package memutils

// 设置软内存最大值
func setMaxMemory(memoryGB int) {

}