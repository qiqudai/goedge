// Copyright 2021 GoEdge goedge.cdn@gmail.com. All rights reserved.

package utils

import "testing"

func TestLookupCNAME(t *testing.T) {
	t.Log(LookupCNAME("www.yun4s.cn"))
}
